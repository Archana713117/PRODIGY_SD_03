
package com.mycompany.contactmanager;
 import java.io.*;
import java.util.*;

public class ContactManager {
    private static final String FILE_NAME = "contacts.txt";
    private static final Scanner scanner = new Scanner(System.in);
    private static final Map<String, Contact> contacts = new HashMap<>();

    public static void main(String[] args) {
       
        loadContacts();
        boolean running = true;

        while (running) {
            System.out.println("Contact Manager");
            System.out.println("1. Add New Contact");
            System.out.println("2. View Contacts");
            System.out.println("3. Edit Contact");
            System.out.println("4. Delete Contact");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (option) {
                case 1:
                    addContact();
                    break;
                case 2:
                    viewContacts();
                    break;
                case 3:
                    editContact();
                    break;
                case 4:
                    deleteContact();
                    break;
                case 5:
                    saveContacts();
                    System.out.println("Exiting the program...");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }

        scanner.close();
    }

    private static void addContact() {
        System.out.print("Enter contact name: ");
        String name = scanner.nextLine();
        System.out.print("Enter phone number: ");
        String phone = scanner.nextLine();
        System.out.print("Enter email address: ");
        String email = scanner.nextLine();

        contacts.put(name, new Contact(name, phone, email));
        System.out.println("Contact added successfully.");
    }

    private static void viewContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            for (Contact contact : contacts.values()) {
                System.out.println(contact.toString());
            }
        }
    }

    private static void editContact() {
        System.out.print("Enter the name of the contact to edit: ");
        String name = scanner.nextLine();

        Contact contact = contacts.get(name);
        if (contact == null) {
            System.out.println("Contact not found.");
            return;
        }

        System.out.print("Enter new phone number (or press Enter to keep current): ");
        String phone = scanner.nextLine();
        if (!phone.isEmpty()) {
            contact.setPhone(phone);
        }

        System.out.print("Enter new email address (or press Enter to keep current): ");
        String email = scanner.nextLine();
        if (!email.isEmpty()) {
            contact.setEmail(email);
        }

        System.out.println("Contact updated successfully.");
    }

    private static void deleteContact() {
        System.out.print("Enter the name of the contact to delete: ");
        String name = scanner.nextLine();

        if (contacts.remove(name) != null) {
            System.out.println("Contact deleted successfully.");
        } else {
            System.out.println("Contact not found.");
        }
    }

    private static void loadContacts() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    contacts.put(parts[0], new Contact(parts[0], parts[1], parts[2]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading contacts: " + e.getMessage());
        }
    }

    private static void saveContacts() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Contact contact : contacts.values()) {
                writer.write(contact.toFileFormat());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving contacts: " + e.getMessage());
        }
    }

    private static class Contact {
        private String name;
        private String phone;
        private String email;

        public Contact(String name, String phone, String email) {
            this.name = name;
            this.phone = phone;
            this.email = email;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String toString() {
            return "Name: " + name + ", Phone: " + phone + ", Email: " + email;
        }

        public String toFileFormat() {
            return name + "," + phone + "," + email;
        }
    }
}
    

